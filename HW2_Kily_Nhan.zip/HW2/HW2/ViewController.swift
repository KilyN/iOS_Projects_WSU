//
//  ViewController.swift
//  HW2
//
//  Created by Kily N on 1/24/17.
//  Copyright © 2017 Kily N. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    var jokes:[Joke] = []
    var ct=0
    
    @IBOutlet weak var first: UILabel!
    
    
    
    @IBOutlet weak var second: UILabel!
    
    
    
    
    @IBOutlet weak var third: UILabel!
    
    
    
    
    @IBAction func buttonPress(_ sender: UIButton) {
        
        if (ct == 0){
     
           
            sender.setTitle("New Joke", for: .normal)
            line4.isHidden = false

            ct = 1;
        
        }
        else{
            
            chooseJoke()
            sender.setTitle("Answer", for: .normal)
            line4.isHidden = true
            
            ct = 0;
        }
        
        
    }
    
    
    @IBOutlet weak var line4: UILabel!
    
    func chooseJoke()
    {
        
        let randomJokeIndex = Int(arc4random_uniform(UInt32(self.jokes.count)))
        
        //print(jokes[randomJokeIndex])
        
        first.text = jokes[randomJokeIndex].firstLine
        second.text = jokes[randomJokeIndex].secondLine
        third.text = jokes[randomJokeIndex].thirdLine
        line4.text = jokes[randomJokeIndex].answerLine1
        
    }
    
    
    
    func initializeJokes()
        
    {
        let joke0 = Joke(fLine: "How many programmer",sLine: "does it take",tLine: "to change lighbulb",ansLine1: "Zero, because it's a hardware problem!!")
        self.jokes.append(joke0)
        
        
        let joke1 = Joke(fLine: "Why is",sLine: "the int",tLine: "drown",ansLine1: "because it couldn't float!!")
        self.jokes.append(joke1)
        
        let joke2 = Joke(fLine: "What does",sLine: "a fish say",tLine: "when it hit the wall",ansLine1: "damn!!")
        self.jokes.append(joke2)
        
        
    }
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initializeJokes();
        first.text = jokes[0].firstLine
        second.text=jokes[0].secondLine
        third.text = jokes[0].thirdLine
   
        line4.text = jokes[0].answerLine1
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

