//
//  ViewController.swift
//  Notification
//
//  Created by Kily N on 2/27/17.
//  Copyright © 2017 Kily N. All rights reserved.
//

import UIKit
import UserNotifications


class ViewController: UIViewController {

    var notificationOkay = false
    
    
    @IBOutlet weak var messageLabel: UILabel!
    
    @IBAction func scheduleBtn(_ sender: UIButton) {
        
        if (notificationOkay)
        {
            scheduleNotification1()
            
            
        }
        else
        {
            messageLabel.text = "Notification Diabled"
            
        }
        
        
        
    }
    
    var jokes:[Joke] = []
    var ct=0
    
    var stri:[String] = []
    
    func initializeJokes()
        
    {
        let joke0 = Joke(fLine: "How many programmer",sLine: "does it take",tLine: "to change lighbulb?",ansLine1: "Zero, because it's a hardware problem!!")
        self.jokes.append(joke0)
        
        
        let joke1 = Joke(fLine: "Why does",sLine: "the int",tLine: "drown?",ansLine1: "because it couldn't float!!")
        self.jokes.append(joke1)
        
        let joke2 = Joke(fLine: "What do",sLine: "you call",tLine: "a Fish withou eye?",ansLine1: "Fsh!")
        self.jokes.append(joke2)
        
        let joke3 = Joke(fLine: "What was six",sLine: "afraid of",tLine: "seven?",ansLine1: "Because seven eight nine")
        self.jokes.append(joke3)
        
        let joke4 = Joke(fLine: "What does",sLine: "a fish say",tLine: "when it hit the wall?",ansLine1: "damn!!")
        self.jokes.append(joke4)
        
        let joke5 = Joke(fLine: "How do you know",sLine: "if a restaurant",tLine: " has a clown as a chef?",ansLine1: "When the food tastes funny...")
        self.jokes.append(joke5)
        
        let joke6 = Joke(fLine: "What goes",sLine: "up and down",tLine: "but does not move?",ansLine1: "Stairs")
        self.jokes.append(joke6)
        
        let joke7 = Joke(fLine: "What did one ",sLine: "wall say to",tLine: "the other wall?",ansLine1: "I'll meet you at the corner.")
        self.jokes.append(joke7)
        
        
        
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
         initializeJokes();
        // HW 7:
        
        if (notificationOkay)
        {
            print("notice is allowed")
            
            
        }else {print("notice is not allowed")}
        
        
        
        
        
    }

    // handle authorization changes
    
    func checkIfNotificationsStillOkay() {
        let center = UNUserNotificationCenter.current()
        center.getNotificationSettings(completionHandler:
            self.handleNotificationSettings)
    }
    
    
    func handleNotificationSettings (notificationSettings:
        UNNotificationSettings) {
        if ((notificationSettings.alertSetting == .enabled) &&
            (notificationSettings.badgeSetting == .enabled) &&
            (notificationSettings.soundSetting == .enabled)) {
            self.notificationOkay = true
        } else {
            self.notificationOkay = false
        }
    }
    
    
    func scheduleNotification1() {
        
        let randomJokeIndex = Int(arc4random_uniform(UInt32(self.jokes.count)))
        
        
        let content = UNMutableNotificationContent()
        content.title = "**Notification from HW7**"
        content.body = jokes[randomJokeIndex].firstLine + " " + jokes[randomJokeIndex].secondLine + " " + jokes[randomJokeIndex].thirdLine
        
        content.userInfo["message"] = jokes[randomJokeIndex].answerLine1
        
        // Configure trigger for 5 seconds from now
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5.0,
                                                        repeats: false)
        // Create request
        let request = UNNotificationRequest(identifier: "NowPlusFive",
                                            content: content, trigger: trigger)
        // Schedule request
        let center = UNUserNotificationCenter.current()
        center.add(request) { (error : Error?) in
            if let theError = error {
                print(theError.localizedDescription)
            }
        }
    }
    
    
    // receiving notification
    func handleNotification1 (_ response: UNNotificationResponse) {
        let message = response.notification.request.content.userInfo["message"]
            as! String
        self.messageLabel.text = message
    }
    

    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

