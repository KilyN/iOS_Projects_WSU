//
//  Joke.swift
//  Notification
//
//  Created by Kily N on 2/27/17.
//  Copyright © 2017 Kily N. All rights reserved.
//

import Foundation

class Joke
    
{
    
    var firstLine:  String;
    var secondLine: String;
    var thirdLine:  String;
    var answerLine1:String;
    
    
    init(fLine:String, sLine:String, tLine:String, ansLine1:String)
    {
        self.firstLine = fLine;
        self.secondLine = sLine;
        self.thirdLine = tLine;
        self.answerLine1 = ansLine1;
        
    }
}
