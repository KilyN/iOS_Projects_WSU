//
//  ViewController.swift
//  joker2
//
//  Created by Larry Holder on 1/18/17.
//  Copyright © 2017 Washington State University. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstLineLabel: UILabel!
    @IBOutlet weak var secondLineLabel: UILabel!
    @IBOutlet weak var thirdLineLabel: UILabel!
    @IBOutlet weak var answerLineLabel: UILabel!
    @IBOutlet weak var answerButton: UIButton!
    
    var count = 1
    var arrJoke =  arrayJoke()
    
    @IBAction func viewJoke(_ sender: Any) {
    }
   // @IBAction func addJokeFunc(_ sender: Any) {
        
        
       // shouldPerformSegue(withIdentifier: "firstToSecond", sender: self)
        
    
   // }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let secondVC:viewJoke = segue.destination as! viewJoke
        
        secondVC.arrJokeReceive = arrJoke;
        secondVC.lineCount  = count
        
       
        
        
    }
    
    
    @IBAction func unwindFromSecondView(sender: UIStoryboardSegue)
    {
        
        
        let addJoke = sender.source as! AddJokeViewController
        //var jokeStore = sender.source as! ViewController    // new variable joke to hold
         let newJ = addJoke.joke
        
        if (addJoke.textField1.text != "" &&
            addJoke.testField2.text != "" &&
            addJoke.textField3.text != "" &&
            addJoke.textFieldAnswer.text != "")
        {
            
            arrJoke.adddJoke(newJ)
            count += 1
        
        }
        
        
        
//        let Jokeline1 = addJoke.textField1.text!
//       let Jokeline2 = addJoke.testField2.text!
//       let Jokeline3 = addJoke.textField3.text!
//        let answerJoke = addJoke.textFieldAnswer.text!
        
       
        //let newJoke = Joke(Jokeline1,Jokeline2,Jokeline3,answerJoke)
        
        //jokes.append(newJoke)
        
        
        
        // var j = jokeStore.Joke(Jokeline1,Jokeline2,Jokeline3,answerJoke)
        //jokeStore.append(j)
        
       // count += 1    // add to count
        
    }

    
    @IBAction func answerButtonTapped(_ sender: UIButton) {
        // if Answer hidden, then unhide answer line and change button to New Joke
        // else choose new joke
        if (answerLineLabel.isHidden) {
            answerLineLabel.isHidden = false
            answerButton.setTitle("New Joke", for: .normal)
        } else {
            chooseJoke()
        }
    }
    
    var jokes: [Joke] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
                // Do any additional setup after loading the view, typically from a nib.
        initializeJokes()
        chooseJoke()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func initializeJokes() {
        var joke = Joke("How many programmers", "does it take to", "change a lightbulb?", "Zero. That's a hardware problem.")
        //self.jokes.append(joke)
        arrJoke.adddJoke(joke)
        joke = Joke("What did the fish say", "when it ran into a wall?", "", "Dam.")
         arrJoke.adddJoke(joke)
        
        //self.jokes.append(joke)
        joke = Joke("A horse walked into a bar,", "and the bartender said...", "", "Why the long face?")
         arrJoke.adddJoke(joke)
        //self.jokes.append(joke)
    }
    
    func chooseJoke() {
        // change button to "Answer"
        answerButton.setTitle("Answer", for: .normal)
        // hide answer label
        answerLineLabel.isHidden = true
        // choose a joke from the array at random
        let randomJokeIndex = Int(arc4random_uniform(UInt32(arrJoke.myArray.count)))
        //let joke = jokes[randomJokeIndex]
        let joke = arrJoke.myArray[randomJokeIndex]
        // set view labels accordingly
        firstLineLabel.text = joke.firstLine
        secondLineLabel.text = joke.secondLine
        thirdLineLabel.text = joke.thirdLine
        answerLineLabel.text = joke.answerLine
    }


}

