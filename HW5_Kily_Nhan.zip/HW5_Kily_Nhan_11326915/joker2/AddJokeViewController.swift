//
//  AddJokeViewController.swift
//  joker2
//
//  Created by Kily N on 2/7/17.
//  Copyright © 2017 Adaptelligence. All rights reserved.
//

import UIKit //4

class AddJokeViewController: UIViewController, UITextFieldDelegate {
    
    var joke = Joke("", "", "", "")
    
    var receiveCount = 0
   
    
    @IBOutlet weak var titlelabel: UILabel!
    @IBOutlet weak var textField1: UITextField!
    @IBOutlet weak var testField2: UITextField!
    @IBOutlet weak var textField3: UITextField!
    @IBOutlet weak var textFieldAnswer: UITextField!
    

    @IBAction func cancelButton(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    @IBAction func saveButton(_ sender: Any) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        textField1.delegate=self
        testField2.delegate=self
        textField3.delegate=self
        textFieldAnswer.delegate=self
        
        
        titlelabel.text = "Enter New Joke # \(receiveCount)"
        
        
        
    }
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        joke.firstLine = textField1.text!
        joke.secondLine = testField2.text!
        joke.thirdLine = textField3.text!
        joke.answerLine = textFieldAnswer.text!
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
