//
//  EditAndViewViewController.swift
//  Joker5
//
//  Created by Kily N on 4/4/17.
//  Copyright © 2017 Larry Holder. All rights reserved.
//

import UIKit
import CoreData

class EditAndViewViewController: UIViewController, UITextFieldDelegate {
    
    var list = [NSManagedObject]()
    
    var managedObjectContext: NSManagedObjectContext!
    var appDelegate: AppDelegate!
    
    var toDelete = Joke()
    
    @IBOutlet weak var displayLine1: UILabel!
    
    
    @IBOutlet weak var displayLine2: UILabel!
    
    
    @IBOutlet weak var displayLine3: UILabel!
    
    @IBOutlet weak var displayLine4: UILabel!
    
    @IBOutlet weak var line1TextField: UITextField!
    
    @IBOutlet weak var line2TextField: UITextField!
    
    @IBOutlet weak var line3TextField: UITextField!
    
    
    @IBOutlet weak var line4TextField: UITextField!
    
    
    
    @IBAction func saveBtn(_ sender: Any) {
        
        
        
        var editFirstLine = ""
        var editSecondLine = ""
        var editThirdLine = ""
        var editAnswerLine = ""
        
        editFirstLine = line1TextField.text!
        editSecondLine = line2TextField.text!
        editThirdLine = line3TextField.text!
        editAnswerLine = line4TextField.text!
        
        
        self.appDelegate = UIApplication.shared.delegate as! AppDelegate
        self.managedObjectContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "JokeEntity")
        var players: [NSManagedObject]!
        do {
            players = try self.managedObjectContext.fetch(fetchRequest)
            
            if (players.count != 0)
            {
                
                //                let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "JokeEntity")
                fetchRequest.predicate = NSPredicate(format: "firstLine == %@", toDelete.firstLine)
                var players: [NSManagedObject]!
                do {
                    players = try self.managedObjectContext.fetch(fetchRequest)
                    
                    
                    
                } catch {
                    print("Error: removeJoke: \(error)")
                }
                
                for player in players {
                    
                    self.managedObjectContext.delete(player)
                }
                self.appDelegate.saveContext() // In AppDelegate.swift
                //              self.tableView.reloadData()
                
                
                
                
                
                let addJoke = NSEntityDescription.insertNewObject(forEntityName:
                    "JokeEntity", into: self.managedObjectContext)
                
                addJoke.setValue(editFirstLine, forKey: "firstLine")
                addJoke.setValue(editSecondLine, forKey: "secondLine")
                addJoke.setValue(editThirdLine, forKey: "thirdLine")
                addJoke.setValue(editAnswerLine, forKey: "answerLine")
                self.appDelegate.saveContext()
                
                try managedObjectContext.save()
                
            }
        }catch let error as NSError{
            
            print("Could not Fetch\(error)")
        }
        
        
        
        //            //  func addJokes() {
        //            let addJoke = NSEntityDescription.    insertNewObject(forEntityName:
        //                "JokeEntity", into: self.managedObjectContext)
        //
        //            addJoke.setValue(line1TextField.text, forKey: "firstLine")
        //            addJoke.setValue(line2TextField.text, forKey: "secondLine")
        //            addJoke.setValue(line3TextField.text, forKey: "thirdLine")
        //            addJoke.setValue(line4TextField.text, forKey: "answerLine")
        
        
        
        
        
        
    }
    var line1 = ""
    var line2 = ""
    var line3 = ""
    var line4 = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        line1TextField.delegate = self
        line2TextField.delegate = self
        line3TextField.delegate = self
        line4TextField.delegate = self
        
        // Do any additional setup after loading the view.
        self.appDelegate = UIApplication.shared.delegate as! AppDelegate
        self.managedObjectContext = appDelegate.persistentContainer.viewContext
        
        displayLine1.text = line1
        displayLine2.text = line2
        displayLine3.text = line3
        displayLine4.text = line4
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
