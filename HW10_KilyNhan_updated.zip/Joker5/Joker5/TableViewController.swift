//
//  TableViewController.swift
//  Joker5
//
//  Created by Larry Holder on 2/8/17.
//  Copyright © 2017 Larry Holder. All rights reserved.
//

import UIKit
import CoreData

class TableViewController: UITableViewController {
    
    var managedObjectContext: NSManagedObjectContext!
    var appDelegate: AppDelegate!
    
    var jokeStore: JokeStore!
    
    var store = Joke()
    
    var storeIndex: IndexPath!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.appDelegate = UIApplication.shared.delegate as! AppDelegate
        self.managedObjectContext = appDelegate.persistentContainer.viewContext
        self.tableView.reloadData()
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("row \(indexPath.row) ")
        
        storeIndex = indexPath
        
        
        store = self.jokeStore.getJoke(atIndex: indexPath.row)
        
        // self.jokeStore.remove(atIndex: indexPath.row)
        //tableView.deleteRows(at: [indexPath], with: .fade)
        
        
        
        performSegue(withIdentifier: "toViewAndEdit", sender: self)
        
    }
    
    
    
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return self.jokeStore.count()
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "jokeCell", for: indexPath)
        
        
        
        
        // Configure the cell...
        let joke = self.jokeStore.getJoke(atIndex: indexPath.row)
        cell.textLabel?.text = joke.firstLine
        return cell
    }
    
    
    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    
    
    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
        
        
    {
        
        let jokeName = self.jokeStore.getJoke(atIndex: indexPath.row)
        
        
        
        
        
        if editingStyle == .delete {
            // Delete the row from the data source
            self.jokeStore.remove(atIndex: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            
            let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "JokeEntity")
            fetchRequest.predicate = NSPredicate(format: "firstLine == %@", jokeName.firstLine)
            var players: [NSManagedObject]!
            do {
                players = try self.managedObjectContext.fetch(fetchRequest)
                
                
                
            } catch {
                print("Error: removeJoke: \(error)")
            }
            
            for player in players {
                
                self.managedObjectContext.delete(player)
            }
            self.appDelegate.saveContext() // In AppDelegate.swift
            self.tableView.reloadData()
            
            
            
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }
    
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if (segue.identifier == "toAddJoke") {
            let addJokeVC = segue.destination as! AddJokeViewController
            addJokeVC.numJokes = self.jokeStore.count()
        }
        
        if (segue.identifier == "toViewAndEdit") {
            let addJokeVC = segue.destination as! EditAndViewViewController
            addJokeVC.line1 = store.firstLine
            addJokeVC.line2 = store.secondLine
            addJokeVC.line3 = store.thirdLine
            addJokeVC.line4 = store.answerLine
            
            
            
        }
        
        
    }
    
    
    @IBAction func unwindToTable (sender: UIStoryboardSegue) {
        
        if (sender.source .isKind(of: EditAndViewViewController.self))
        {
            
            
            
            
            
            let addJoke = sender.source as! EditAndViewViewController
            
            addJoke.toDelete = store
            jokeStore.remove(atIndex: storeIndex.row)
            tableView.deleteRows(at: [storeIndex], with: .fade)
            
            
            
            let line1 = addJoke.line1TextField.text!
            //print(line1)
            let line2 = addJoke.line2TextField.text!
            let line3 = addJoke.line3TextField.text!
            //  print(line3)
            let line4 = addJoke.line4TextField.text!
            //  print(line4)
            let joke = Joke(line1,line2,line3,line4)
            self.jokeStore.add(joke)
            
            self.tableView.reloadData()
            
            
            
            
        }
        
        if (sender.source .isKind(of: AddJokeViewController.self) )   {
            let addJokeVC = sender.source as! AddJokeViewController
            if (!addJokeVC.canceled) {
                let joke = addJokeVC.newJoke
                self.jokeStore.add(joke)
                self.tableView.reloadData()
                
            }
        }
        
        
        
        
        
    }
    
    
}
