//
//  ViewController.swift
//  Joker5
//
//  Created by Larry Holder on 1/30/17.
//  Copyright © 2017 Larry Holder. All rights reserved.
//

import UIKit

import CoreData

class ViewController: UIViewController {
    
    
    var managedObjectContext: NSManagedObjectContext!
    var appDelegate: AppDelegate!
    
    
    
    var jokeStore = JokeStore()
    
    @IBOutlet weak var firstLineLabel: UILabel!
    @IBOutlet weak var secondLineLabel: UILabel!
    @IBOutlet weak var thirdLineLabel: UILabel!
    @IBOutlet weak var answerLineLabel: UILabel!
    @IBOutlet weak var answerButton: UIButton!
    
    @IBAction func answerButtonTapped(_ sender: UIButton) {
        // if Answer hidden, then unhide answer line and change button to New Joke
        // else choose new joke
        if (answerLineLabel.isHidden) {
            answerLineLabel.isHidden = false
            answerButton.setTitle("New Joke", for: .normal)
        } else {
            self.chooseJoke()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        
        super.viewDidLoad()
        self.appDelegate = UIApplication.shared.delegate as! AppDelegate
        self.managedObjectContext = appDelegate.persistentContainer.viewContext
        
        
        //  check in database
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "JokeEntity")
        var players: [NSManagedObject]!
        do {
            players = try self.managedObjectContext.fetch(fetchRequest)
        } catch {
            print("getPlayers error: \(error)")
        }
        print("Found \(players.count) jokes!")
        
        if (players.count==0)
        {
            
            let addJoke = NSEntityDescription.insertNewObject(forEntityName:
                "JokeEntity", into: self.managedObjectContext)
            
            addJoke.setValue("How many programmers", forKey: "firstLine")
            addJoke.setValue("does it take to", forKey: "secondLine")
            addJoke.setValue("change a lightbulb?", forKey: "thirdLine")
            addJoke.setValue("Zero. That's a hardware problem.", forKey: "answerLine")
            
            
            let addJoke1 = NSEntityDescription.insertNewObject(forEntityName:
                "JokeEntity", into: self.managedObjectContext)
            
            addJoke1.setValue("A horse walked into a bar,", forKey: "firstLine")
            addJoke1.setValue("and the bartender said...", forKey: "secondLine")
            addJoke1.setValue("", forKey: "thirdLine")
            addJoke1.setValue("Why the long face", forKey: "answerLine")
            
            let addJoke2 = NSEntityDescription.insertNewObject(forEntityName:
                "JokeEntity", into: self.managedObjectContext)
            addJoke2.setValue("What did the fish say", forKey: "firstLine")
            addJoke2.setValue("when it ran into a wall?", forKey: "secondLine")
            addJoke2.setValue("", forKey: "thirdLine")
            addJoke2.setValue("Dam.", forKey: "answerLine")
            
            
            self.appDelegate.saveContext()
        }
        
        
        let fetchReq = NSFetchRequest<NSManagedObject>(entityName: "JokeEntity")
        var itemss: [NSManagedObject]!
        do {
            itemss = try self.managedObjectContext.fetch(fetchReq)
            
            if (players.count != 0 )
            {
                for item in players as! [JokeEntity]
                {
                    let items = Joke(item.firstLine!,item.secondLine!,item.thirdLine!,item.answerLine!)
                    self.jokeStore.add(items)
                }
            }
            
            
        } catch {
            print("getPlayers error: \(error)")
        }
        
        
        
        
        chooseJoke()
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func chooseJoke() {
        // change button to "Answer"
        answerButton.setTitle("Answer", for: .normal)
        // hide answer label
        answerLineLabel.isHidden = true
        // choose a joke from the array at random
        let randomJokeIndex = Int(arc4random_uniform(UInt32(self.jokeStore.count())))
        let joke = self.jokeStore.getJoke(atIndex: randomJokeIndex)
        self.displayJoke(joke)
    }
    
    func displayJoke (_ joke: Joke) {
        // Making sure each label has something will keep the Answer button from jumping around
        if (joke.firstLine.isEmpty) {
            firstLineLabel.text = " "
        } else {
            firstLineLabel.text = joke.firstLine
        }
        if (joke.secondLine.isEmpty) {
            secondLineLabel.text = " "
        } else {
            secondLineLabel.text = joke.secondLine
        }
        if (joke.thirdLine.isEmpty) {
            thirdLineLabel.text = " "
        } else {
            thirdLineLabel.text = joke.thirdLine
        }
        if (joke.answerLine.isEmpty) {
            answerLineLabel.text = " "
        } else {
            answerLineLabel.text = joke.answerLine
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "toJokesTable") {
            let jokesTableVC = segue.destination as! TableViewController
            jokesTableVC.jokeStore = self.jokeStore
        }
    }
    
}

