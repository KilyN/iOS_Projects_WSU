//
//  GameViewController.swift
//  HW11_Kily

//  Copyright © 2017 Kily Nhan. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit
import AVFoundation



class GameViewController: UIViewController {
    
    
    var Player: AVAudioPlayer!
    
    let defaults = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
        defaults.set(true, forKey: "soundEffects")
        defaults.set(true, forKey: "backGroundMusic")
        if let view = self.view as! SKView? {
            // Load the SKScene from 'GameScene.sks'
            if let scene = GameScene(fileNamed: "GameScene") {
                // Set the scale mode to scale to fit the window
                scene.scaleMode = .aspectFill
                
                // Present the scene
                view.presentScene(scene)
                Player = scene.audioPlayer;
            }
            
            view.ignoresSiblingOrder = true
            
            view.showsFPS = true
            view.showsNodeCount = true
        }
    }
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    @IBAction func unwindFromSecondView (sender: UIStoryboardSegue) {
        // let firstViewController: GameViewController = sender.destination as! GameViewController
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let secondViewController: settingViewController = segue.destination as! settingViewController
        
        
        
        secondViewController.audioPlayer = Player
        
    }
    
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
}
