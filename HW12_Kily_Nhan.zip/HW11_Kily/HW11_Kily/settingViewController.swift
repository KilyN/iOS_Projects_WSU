//
//  settingViewController.swift
//  HW11_Kily
//
//  Created by Kily N on 4/18/17.
//  Copyright © 2017 Kily Nhan. All rights reserved.
//

import UIKit
import AVFoundation

class settingViewController: UIViewController {
    
    let SEKey = "soundEffects"
    let BGM = "backGroundMusic"
    var audioPlayer: AVAudioPlayer!
    
    
    @IBOutlet weak var soundEffectSwitch: UISwitch!
    
    
    @IBAction func doneBTN(_ sender: UIButton) {
        
        performSegue(withIdentifier: "unwindback", sender: self)
        
    }
    @IBOutlet weak var backGroundMusicSwitch: UISwitch!
    
    @IBAction func soundEffect(_ sender: UISwitch) {
        
        let defaults = UserDefaults.standard
        if (sender.isOn){
            defaults.set(true, forKey: SEKey)
            
        }else{
            defaults.set(false, forKey: SEKey)
            
        }
        
        
    }
    
    
    @IBAction func backGroundMusic(_ sender: UISwitch){
        let defaults = UserDefaults.standard
        if (!sender.isOn)
        {
            
            defaults.set(false, forKey: BGM)
            audioPlayer?.stop()
        }
        else{
            
            defaults.set(true, forKey: BGM)
            audioPlayer?.play()
            
            
        }
    }
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        let defaults = UserDefaults.standard
        
        if (defaults.bool(forKey: BGM))
        {
            backGroundMusicSwitch.setOn(true, animated: true)
        }else{
            
            backGroundMusicSwitch.setOn(false, animated: true)
        }
        
        if(defaults.bool(forKey: SEKey))
        {
            soundEffectSwitch.setOn(true, animated: true)
        }else{
            soundEffectSwitch.setOn(false, animated: true)
        }
        
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
