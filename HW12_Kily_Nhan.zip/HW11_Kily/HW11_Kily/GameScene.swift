//
//  GameScene.swift
//  HW11_Kily
//
//
//  Copyright © 2017 Kily Nhan. All rights reserved.
//

import SpriteKit
import GameplayKit
import AVFoundation

class GameScene: SKScene , SKPhysicsContactDelegate{
    
    // private var label : SKLabelNode?
    //private var spinnyNode : SKShapeNode?
    
    var redBallNode: SKSpriteNode!
    var greenBallNode: SKSpriteNode!
    var startStopLabel: SKLabelNode!
    
    var screenPhysicsBody: SKPhysicsBody!
    var greenPosition : CGPoint!
    var bounceSoundAction : SKAction!
    var audioPlayer: AVAudioPlayer!
    var glassBreakSound : SKAction!
    
    
    
    override func didMove(to view: SKView) {
        
        
        // Make walls bouncy
        screenPhysicsBody = SKPhysicsBody(edgeLoopFrom: self.frame)
        
        screenPhysicsBody.friction = 0.0
        screenPhysicsBody.categoryBitMask = 0b100
        
        // greenBall to screenPhysicBody
        screenPhysicsBody.collisionBitMask = 0b110
        screenPhysicsBody.contactTestBitMask = 0b001
        
        self.physicsBody = screenPhysicsBody
        
        
        redBallNode = self.childNode(withName: "RedBall") as! SKSpriteNode
        
        
        startStopLabel = self.childNode(withName: "StartStop") as! SKLabelNode
        
        physicsWorld.contactDelegate = self
        
        self.initGame()
        
        
        
        
        
        
        //
        //        // Get label node from scene and store it for use later
        //        self.label = self.childNode(withName: "//helloLabel") as? SKLabelNode
        //        if let label = self.label {
        //            label.alpha = 0.0
        //            label.run(SKAction.fadeIn(withDuration: 2.0))
        //        }
        //
        //        // Create shape node to use during mouse interaction
        //        let w = (self.size.width + self.size.height) * 0.05
        //        self.spinnyNode = SKShapeNode.init(rectOf: CGSize.init(width: w, height: w), cornerRadius: w * 0.3)
        //
        //        if let spinnyNode = self.spinnyNode {
        //            spinnyNode.lineWidth = 2.5
        //
        //            spinnyNode.run(SKAction.repeatForever(SKAction.rotate(byAngle: CGFloat(Double.pi), duration: 1)))
        //            spinnyNode.run(SKAction.sequence([SKAction.wait(forDuration: 0.5),
        //                                              SKAction.fadeOut(withDuration: 0.5),
        //                                              SKAction.removeFromParent()]))
        //        }
    }
    
    
    func didBegin(_ contact: SKPhysicsContact) {
        let bodyNameA = String(describing: contact.bodyA.node?.name)
        let bodyNameB = String(describing: contact.bodyB.node?.name)
        
        let defaults = UserDefaults.standard
        
        
        
        
        if (bodyNameA.contains("RedBall") && bodyNameB.contains("GreenBall"))
        {
            contact.bodyB.node!.removeFromParent() // remove greenBall
            
            if(defaults.bool(forKey: "soundEffects")){
                run(glassBreakSound)}
            
            
            //print("Contact: \(bodyNameA), \(bodyNameB)")
            
            
        }
        
        if ((!bodyNameA.contains("GreenBall")) && (!bodyNameB.contains("GreenBall")))
        {
            print("hit walllllll") // must be the redBall hits the wall
            if(defaults.bool(forKey: "soundEffects")){
                run(bounceSoundAction)
            }
        }
        
        
        
        
        //        let action1 = SKAction.fadeOut(withDuration: 0.25)
        //        let action2 = SKAction.fadeIn(withDuration: 0.25)
        //
        //        let blinkAction = SKAction.sequence([action1,action2])
        //
        //        contact.bodyA.node?.run(blinkAction)
        //        contact.bodyB.node?.run(blinkAction)
        
        
        
        
        
    }
    
    
    
    func startGame () {
        self.isPaused = false
        self.startStopLabel.text = "Stop"
        redBallNode.physicsBody?.applyImpulse(CGVector(dx: 200.0, dy: 200.0))
        audioPlayer.play()
    }
    
    func pauseGame () {
        self.isPaused = true
        self.startStopLabel.text = "Start"
        audioPlayer.pause()
        //print("END OF PAUSE GAME")
    }
    
    
    func initGame()
    {
        
        glassBreakSound = SKAction.playSoundFileNamed("glassbreak.mp3", waitForCompletion: false)
        
        
        bounceSoundAction = SKAction.playSoundFileNamed("bounce.mp3", waitForCompletion: false)
        
        let musicURL = Bundle.main.url(forResource: "WSU-Fight-Song.mp3", withExtension: nil)
        
        do{
            audioPlayer = try AVAudioPlayer(contentsOf: musicURL!)
            
        }
        catch{
            print("Can't access to music")
            
            
        }
        audioPlayer.volume = 0.50
        audioPlayer.numberOfLoops = -1 // loop music forever
        
        
        
    }
    
    func addGreenball(point: CGPoint)
    {
        greenBallNode = SKSpriteNode(imageNamed: "greenBall.png")
        greenBallNode.name = "GreenBall"
        greenBallNode.physicsBody = SKPhysicsBody(circleOfRadius: 50.0)
        greenBallNode.physicsBody?.affectedByGravity = false
        greenBallNode.position = CGPoint(x: point.x, y: point.y)
        greenPosition = greenBallNode.position
        greenBallNode.physicsBody?.friction = 0.0
        greenBallNode.physicsBody?.restitution = 1.0
        greenBallNode.physicsBody?.linearDamping = 0.0
        greenBallNode.physicsBody?.categoryBitMask = 0b001
        greenBallNode.physicsBody?.collisionBitMask = 0b110
        greenBallNode.physicsBody?.contactTestBitMask = 0b001
        greenBallNode.physicsBody!.isDynamic = false
        self.addChild(greenBallNode)
        
        
        
    }
    
    
    
    func touchDown(atPoint pos : CGPoint) {
        //        if let n = self.spinnyNode?.copy() as! SKShapeNode? {
        //            n.position = pos
        //            n.strokeColor = SKColor.green
        //            self.addChild(n)
        //        }
    }
    
    func touchMoved(toPoint pos : CGPoint) {
        //        if let n = self.spinnyNode?.copy() as! SKShapeNode? {
        //            n.position = pos
        //            n.strokeColor = SKColor.blue
        //            self.addChild(n)
        //        }
    }
    
    func touchUp(atPoint pos : CGPoint) {
        //        if let n = self.spinnyNode?.copy() as! SKShapeNode? {
        //            n.position = pos
        //            n.strokeColor = SKColor.red
        //            self.addChild(n)
        //        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //        if let label = self.label {
        //            label.run(SKAction.init(named: "Pulse")!, withKey: "fadeInOut")
        //        }
        //
        //        for t in touches { self.touchDown(atPoint: t.location(in: self)) }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        // for t in touches { self.touchMoved(toPoint: t.location(in: self)) }
        
        
        
        
        
        
        
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        //for t in touches { self.touchUp(atPoint: t.location(in: self)) }
        
        
        
        //    let touchBall = SKSpriteNode.init()
        //
        for touch in touches {
            let point = touch.location(in: self)
            let nodeArray = nodes(at: point)       // condtain cordinate
            
            ////
            
            
            /////
            print(nodeArray)
            
            
            if (nodeArray.count == 0)
            {
                addGreenball(point: point)
            }
            
            for node in nodeArray {
                if (node.name == "StartStop" ){
                    if (self.isPaused )
                    {
                        self.startGame()
                        
                    }
                    else
                    {
                        self.pauseGame()
                        print("pause in bottom")
                        
                    }
                    
                }
                else if (node.name == "settings"){
                    
                    self.view!.window!.rootViewController!.performSegue(withIdentifier: "goSettings", sender: self.view!.window!.rootViewController)
                }
                
                
                
            }
        }
        
        
        
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        //        for t in touches { self.touchUp(atPoint: t.location(in: self)) }
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}
