//
//  Joke.swift
//  HW2
//
//  Created by Kily N on 1/24/17.
//  Copyright © 2017 Kily N. All rights reserved.
//

import Foundation

class Joke
    
{
    
    var firstLine:  String;
    var secondLine: String;
    var thirdLine:  String;
    var answerLine1:String;
    var rating : Int;
    
    
    init(fLine:String, sLine:String, tLine:String, ansLine1:String, newRating:Int)
    {
        self.firstLine = fLine;
        self.secondLine = sLine;
        self.thirdLine = tLine;
        self.answerLine1 = ansLine1;
        self.rating = newRating;
    }
}
