//
//  ViewController.swift
//  HW2
//
//  Created by Kily N on 1/24/17.
//  Copyright © 2017 Kily N. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIGestureRecognizerDelegate {

    
    
    @IBOutlet weak var image1: UIImageView!
    
    @IBOutlet weak var image2: UIImageView!
    
    @IBOutlet weak var image3: UIImageView!
    
    @IBOutlet weak var image4: UIImageView!
    
    @IBOutlet weak var image5: UIImageView!
    
    
    @IBOutlet weak var jokeNum: UILabel!
    
    var ct = 1
    var jokes:[Joke] = []
    var index = 0
    
    @IBOutlet weak var first: UILabel!
    @IBOutlet weak var second: UILabel!
    @IBOutlet weak var third: UILabel!
    @IBOutlet weak var line4: UILabel!
    
    
    func chooseJoke()
    {
        
        let randomJokeIndex = Int(arc4random_uniform(UInt32(self.jokes.count)))
        
        //print(jokes[randomJokeIndex])
        
        first.text = jokes[randomJokeIndex].firstLine
        second.text = jokes[randomJokeIndex].secondLine
        third.text = jokes[randomJokeIndex].thirdLine
        line4.text = jokes[randomJokeIndex].answerLine1
        
    }
    
    
    
    func initializeJokes()
        
    {
        let joke0 = Joke(fLine: "How many programmer",sLine: "does it take",tLine: "to change lighbulb",ansLine1: "Zero, because it's a hardware problem!!",newRating: 0)
        self.jokes.append(joke0)
        
        
        let joke1 = Joke(fLine: "Why is",sLine: "the int",tLine: "drown",ansLine1: "because it couldn't float!!",newRating:0)
        self.jokes.append(joke1)
        
        let joke2 = Joke(fLine: "What does",sLine: "a fish say",tLine: "when it hit the wall",ansLine1: "damn!!",newRating:0)
        self.jokes.append(joke2)
        
        let joke3 = Joke(fLine: "How do you know",sLine: "if a restaurant",tLine: " has a clown as a chef?",ansLine1: "When the food tastes funny...",newRating:0)
        self.jokes.append(joke3)
        
        let joke4 = Joke(fLine: "What goes",sLine: "up and down",tLine: "but does not move?",ansLine1: "Stairs",newRating:0)
        self.jokes.append(joke4)
        
        
        
    }
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        jokeNum.text = "Joke \(ct)"
        
        initializeJokes();
        first.text = jokes[index].firstLine
        second.text=jokes[index].secondLine
        third.text = jokes[index].thirdLine
        line4.text = jokes[index].answerLine1   // answer
        
        
        let tapGestureRecognizer1 = UITapGestureRecognizer(target: self, action: #selector(handleTap1))
        let tapGestureRecognizer2 = UITapGestureRecognizer(target: self, action: #selector(handleTap2))
        let tapGestureRecognizer3 = UITapGestureRecognizer(target: self, action: #selector(handleTap3))
        let tapGestureRecognizer4 = UITapGestureRecognizer(target: self, action: #selector(handleTap4))
        let tapGestureRecognizer5 = UITapGestureRecognizer(target: self, action: #selector(handleTap5))

        
        
        let leftSwipe = UISwipeGestureRecognizer(target: self, action: #selector(ViewController.respond(gesture:)))
        leftSwipe.direction = .left
        view.addGestureRecognizer(leftSwipe)
        
        let rightSwipe = UISwipeGestureRecognizer(target: self, action: #selector(ViewController.respond(gesture:)))
        rightSwipe.direction = .right
        view.addGestureRecognizer(rightSwipe)
        
        
        image1.addGestureRecognizer(tapGestureRecognizer1)
        image2.addGestureRecognizer(tapGestureRecognizer2)

        image3.addGestureRecognizer(tapGestureRecognizer3)

        image4.addGestureRecognizer(tapGestureRecognizer4)

        image5.addGestureRecognizer(tapGestureRecognizer5)

        image1.isUserInteractionEnabled = true
        image2.isUserInteractionEnabled = true
        image3.isUserInteractionEnabled = true
        image4.isUserInteractionEnabled = true
        image5.isUserInteractionEnabled = true
        
        
        
        
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    func handleTap1 (recognizer: UITapGestureRecognizer) {
    if (jokes[index].rating == 1)
    {
    jokes[index].rating = 0
    rateStar()
    }
    else{
    jokes[index].rating = 1
    rateStar()
    }
}

func handleTap2 (recognizer: UITapGestureRecognizer) {
    
    jokes[index].rating = 2
    rateStar()
}

func handleTap3 (recognizer: UITapGestureRecognizer) {
    
    jokes[index].rating = 3
    rateStar()
}

func handleTap4 (recognizer: UITapGestureRecognizer) {
    
    jokes[index].rating = 4
    rateStar()
}

func handleTap5 (recognizer: UITapGestureRecognizer) {
    
    jokes[index].rating = 5
    rateStar()
}


func rateStar()
{
    switch jokes[index].rating {
    case 1:
        image1.image = UIImage(named: "image1.jpg")
        image2.image = UIImage(named: "image.jpg")
        image3.image = UIImage(named: "image.jpg")
        image4.image = UIImage(named: "image.jpg")
        image5.image = UIImage(named: "image.jpg")
        break
    case 2:
        image1.image = UIImage(named: "image1.jpg")
        image2.image = UIImage(named: "image1.jpg")
        image3.image = UIImage(named: "image.jpg")
        image4.image = UIImage(named: "image.jpg")
        image5.image = UIImage(named: "image.jpg")
        break
    case 3:
        image1.image = UIImage(named: "image1.jpg")
        image2.image = UIImage(named: "image1.jpg")
        image3.image = UIImage(named: "image1.jpg")
        image4.image = UIImage(named: "image.jpg")
        image5.image = UIImage(named: "image.jpg")
        break
    case 4:
        image1.image = UIImage(named: "image1.jpg")
        image2.image = UIImage(named: "image1.jpg")
        image3.image = UIImage(named: "image1.jpg")
        image4.image = UIImage(named: "image1.jpg")
        image5.image = UIImage(named: "image.jpg")
        break
    case 5:
        image1.image = UIImage(named: "image1.jpg")
        image2.image = UIImage(named: "image1.jpg")
        image3.image = UIImage(named: "image1.jpg")
        image4.image = UIImage(named: "image1.jpg")
        image5.image = UIImage(named: "image1.jpg")
        break
    default:
        image1.image = UIImage(named: "image.jpg")
        image2.image = UIImage(named: "image.jpg")
        image3.image = UIImage(named: "image.jpg")
        image4.image = UIImage(named: "image.jpg")
        image5.image = UIImage(named: "image.jpg")
    }
}


func respond(gesture: UISwipeGestureRecognizer)
{
    switch gesture.direction {
    case UISwipeGestureRecognizerDirection.right:
        if (index > 0)
        {
            index -= 1
            ct -= 1
            jokeNum.text = "Joke #\(ct)"
            first.text = jokes[index].firstLine
            second.text = jokes[index].secondLine
            third.text = jokes[index].thirdLine
            line4.text = jokes[index].answerLine1
            rateStar()
        }
        else
        {
            if (index == 0)
            {
                index = jokes.count-1
                ct = jokes.count
                if (index > 0)
                {
                    jokeNum.text = "Joke #\(ct)"
                    first.text = jokes[index].firstLine
                    second.text = jokes[index].secondLine
                    third.text = jokes[index].thirdLine
                    line4.text = jokes[index].answerLine1
                    rateStar()
                }
            }
        }
        break
        
    case UISwipeGestureRecognizerDirection.left:
        
        if (index < jokes.count - 1)
        {
            index += 1
            ct += 1
            jokeNum.text = "Joke #\(ct)"
            first.text = jokes[index].firstLine
            second.text = jokes[index].secondLine
            third.text = jokes[index].thirdLine
            line4.text = jokes[index].answerLine1
            rateStar()
        }
        else
        {
            if (index == jokes.count-1)
            {
                index = 0
                ct = 1
                if (index < jokes.count)
                {
                    jokeNum.text = "Joke #\(ct)"
                    first.text = jokes[index].firstLine
                    second.text = jokes[index].secondLine
                    third.text = jokes[index].thirdLine
                    line4.text = jokes[index].answerLine1
                    rateStar()
                }
            }
        }
        break
        
    default:
        break
    }
}






}

