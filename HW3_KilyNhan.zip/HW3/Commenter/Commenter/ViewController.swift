//
//  ViewController.swift
//  Commenter
//
//  Created by Kily N on 1/31/17.
//  Copyright © 2017 Kily N. All rights reserved.
//

import UIKit

var arrayComment : [Comment] = []
var datee = NSDate()

class ViewController: UIViewController , UITextFieldDelegate{
    
    
    
    
    
    
    @IBOutlet weak var textField: UITextField!
    
    
    @IBAction func buttonAdd(_ sender: Any) {
        
        if (textField.text != "")
        {
            
            let cmtSaver = Comment(cmt: textField.text!, dt : datee as Date)
            
            
            arrayComment.append(cmtSaver);
            
            
            textField.text = ""
        }
        
        
        
    }
    
    
    
    @IBAction func printAllButton(_ sender: Any) {
        
        for element in arrayComment{
            print("------------------")
            print(element.comment)
            print(element.date)
            print("------------------")
            
            
        }
    
    }
    
 // to make keyboard disappear
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        textField.delegate = self
       
        
        
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
        
        
        
        
        
    }


}

