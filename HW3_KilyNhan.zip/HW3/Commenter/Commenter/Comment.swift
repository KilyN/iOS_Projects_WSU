//
//  Comment.swift
//  Commenter
//
//  Created by Kily N on 1/31/17.
//  Copyright © 2017 Kily N. All rights reserved.
//

import Foundation


class Comment
{

    var comment : String;
    var date : Date;


    init(cmt: String, dt:  Date)
    {
        self.comment = cmt;
        self.date = dt;
    
    
    
    }

}
