//
//  ViewController.swift
//  HW1-Joke
//
//  Created by LinuxPlus on 1/16/17.
//  Copyright © 2017 Washington State University. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
   
    @IBAction func ButtonPressed(_ sender: UIButton) {
        answerLine.isHidden = false
        
    }
    
    @IBOutlet weak var answerOutlet: UIButton!
    
    
    
    @IBOutlet weak var answerLine: UILabel!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

