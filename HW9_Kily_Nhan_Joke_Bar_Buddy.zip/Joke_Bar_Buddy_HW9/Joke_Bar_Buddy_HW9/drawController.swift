//
//  drawController.swift
//  Joke_Bar_Buddy_HW9
//
//  Created by Kily N on 3/28/17.
//  Copyright © 2017 Kily N. All rights reserved.
//

import UIKit

class drawController: UIViewController {
    
    var arrayOfDot: [UIView] = []
  //  var newArray : [CGPoint] = []
    
    var flagStart  = [Bool]()
    var flagMove = [Bool]()
    var flagEnd  = [Bool]()
    
    var flagStartTotal = true
    var flagMoveTotal = true
    var flagEndTotal = true
    
    
    @IBOutlet weak var finishLabel: UILabel!
    
    
    // @IBOutlet weak var blackSpaceLabel: UILabel!
    
    @IBOutlet weak var startLabel: UILabel!
    
    @IBOutlet weak var imageSpace: UIImageView!
    
    
    
    @IBAction func tryAgainBtn(_ sender: Any) {
        
       // arrayOfDot.removeAll()
        
        for item in arrayOfDot{
            item.removeFromSuperview()
        }
        imageSpace.image = nil
        
        flagStartTotal = true
        flagMoveTotal = true
        flagEndTotal = true
        flagMove.removeAll()
        flagStart.removeAll()
        flagEnd.removeAll()
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            let position = touch.location(in: self.view)
            print("begin = \(position.x), \(position.y)")
            let dotView = UIView(frame: CGRect(x: position.x, y: position.y, width: 5.0, height: 5.0))
            dotView.backgroundColor = UIColor.blue
            arrayOfDot.append(dotView)
           // newArray.append(position)
            self.view.addSubview(dotView)
            print("startingTouch +\( self.startLabel.frame.contains(position))" )
            
            if(self.startLabel.frame.contains(position))    // returns true if contains
            {
                flagStart.append(true)
                
            }else
            {
                flagStart.append(false)
                
            }
            // print(flagStart)
        }
    }
    
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if let touch = touches.first {
            let position = touch.location(in: self.view)
            print("moved = \(position.x), \(position.y)")
            let dotView = UIView(frame: CGRect(x: position.x, y: position.y, width: 5.0, height: 5.0))
            dotView.backgroundColor = UIColor.blue
            arrayOfDot.append(dotView)
           // newArray.append(position)
            self.view.addSubview(dotView)
            //  print("movingTouch +\( self.blackSpaceLabel.frame.contains(position))" )
            
            
            if (position.y >= 214 && position.y <= 223 ){
                
                print ("true in Y range MOVE")
                flagMove.append (true)
                
            }
            else
                
            {
                print("not in range MOVE")
                flagMove.append(false)
                
                
                
            }
            
//            loop: for i in flagMove
//            {
//                print(i)
//            }
            
        }
        
        
    }
    
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            let position = touch.location(in: self.view)
            print("end = \(position.x), \(position.y)")
            let dotView = UIView(frame: CGRect(x: position.x, y: position.y, width: 5.0, height: 5.0))
            dotView.backgroundColor = UIColor.blue
            arrayOfDot.append(dotView)
           // newArray.append(position)
            
            self.view.addSubview(dotView)
            print("TouchEnded +\( self.finishLabel.frame.contains(position))" )
            
            //  var flag = false
            
            
            if(self.finishLabel.frame.contains(position))
            {
                flagEnd.append(true)
                
            }else
            {
                flagEnd.append(false)
                
            }
            
            // print(flagEnd)
            
            
            
            
            
        }
        
        loop: for i in flagMove
        {
            if (i == false)
            {
                
                flagMoveTotal = false
            }
            
        }
        
        loop:for x in flagStart
        {
            if (x == false)
            {
                flagStartTotal = false
            }
        }
        loop:for x in flagEnd
        {
            if (x == false)
            {
                flagEndTotal = false
            }
        }
        
        if (flagStartTotal == true && flagEndTotal == true && flagMoveTotal == true )
        {
            imageSpace.image = UIImage(named: "pass.png")
            
        }
        else
        {
            imageSpace.image = UIImage(named: "failed.png")
        }
        
        
        
        
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
