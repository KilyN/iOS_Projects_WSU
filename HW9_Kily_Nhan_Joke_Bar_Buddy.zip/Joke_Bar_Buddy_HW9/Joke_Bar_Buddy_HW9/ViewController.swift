//
//  ViewController.swift
//  Joke_Bar_Buddy_HW9
//
//  Created by Kily N on 3/27/17.
//  Copyright © 2017 Kily N. All rights reserved.
//

import UIKit
import WebKit
import CoreLocation
import MapKit

class ViewController: UIViewController {
    
    @IBOutlet weak var Line1: UILabel!
    
    
    @IBOutlet weak var Line2: UILabel!
    
    
    @IBOutlet weak var Line3: UILabel!
    
    
    @IBOutlet weak var AnswerLIne: UILabel!
    
    let url = URL(string: "http://www.eecs.wsu.edu/~holder/courses/MAD/hw9/getjoke.php")
    
    
    

    @IBAction func GetJokeBTN(_ sender: UIButton) {
        
        self.Line1.isHidden = false
        self.Line2.isHidden = false
        self.Line3.isHidden = false
        self.AnswerLIne.isHidden = false
        
        
        //let url = URL(String: urlString)
        let dataTask = URLSession.shared.dataTask(with: url!,completionHandler: handleResponse)
        
        dataTask.resume()
     
    }
    
    func handleResponse (data: Data?, response: URLResponse?, error: Error?) {
        
        if (error != nil)
        {
            print("error: \(error!.localizedDescription)")
        }
        else
            {
                do
                {
                    let jsonObj = try JSONSerialization.jsonObject(with: data!,options: []) as! [String: Any]
                
                    let jsonDict = jsonObj["joke"] as! [String: Any]
                    
                    let dateStr1 = jsonDict["line1"] as! String
                    let dateStr2 = jsonDict["line2"] as! String
                    let dateStr3 = jsonDict["line3"] as! String
                    let dateStr4 = jsonDict["answer"] as! String

                    
                    //let dataStr = String(data: data!, encoding: .utf8)
                   // print("data = \(dataStr)")
                    
                    DispatchQueue.main.async{
                        self.Line1.text = dateStr1
                        self.Line2.text = dateStr2
                        self.Line3.text = dateStr3
                        self.AnswerLIne.text = dateStr4
                    }
                   
                }
                catch let error as NSError
                {
                    print(error)
                }
                
        }
        }
        
       
   // }
    
    
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
       
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

