//
//  mapViewController.swift
//  Joke_Bar_Buddy_HW9
//
//  Created by Kily N on 3/28/17.
//  Copyright © 2017 Kily N. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class mapViewController: UIViewController , CLLocationManagerDelegate{

    
   
    @IBOutlet weak var mapView: MKMapView!
    
    // credit to : http://www.techotopia.com/index.php/Working_with_MapKit_Local_Search_in_iOS_8_and_Swift
    
    @IBAction func ShowNearByBars(_ sender: Any) {
        
        let request = MKLocalSearchRequest()
        request.naturalLanguageQuery = "Bar"
        request.region = mapView.region
        
        let search = MKLocalSearch(request: request)
        
        search.start(completionHandler: {(response, error) in
            
            if error != nil {
                print("Error occured in search: \(error!.localizedDescription)")
            } else if response!.mapItems.count == 0 {
                print("No matches found")
            } else {
                print("Matches found")
                
                for item in response!.mapItems {
                                     
                    let annotation = MKPointAnnotation()
                    annotation.coordinate = item.placemark.coordinate
                    annotation.title = item.name
                    self.mapView.addAnnotation(annotation)
                }
            }
        })
            }
    
    
    var locationManager: CLLocationManager!
    
    func initializeLocation() { // called from start up method
        self.locationManager = CLLocationManager()
        self.locationManager.delegate = self
        let status = CLLocationManager.authorizationStatus()
        switch status {
        case .authorizedAlways, .authorizedWhenInUse:
           self.startLocation()
        case .denied, .restricted:
            print("location not authorized")
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()
        }
    }
    
        func locationManager(_ manager: CLLocationManager,
                             didChangeAuthorization status: CLAuthorizationStatus)
        {
            if ((status == .authorizedAlways) || (status == .authorizedWhenInUse)) {
                self.startLocation()
            } else {
                self.stopLocation()
            }
        }
        
        func startLocation () {
            locationManager.distanceFilter = kCLDistanceFilterNone
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.startUpdatingLocation()
        }
        func stopLocation () {
            locationManager.stopUpdatingLocation()
        }
   
    
    func locationManager(_ manager: CLLocationManager,
                         didUpdateLocations locations: [CLLocation])
    {
        
        let userLocation:CLLocation = locations[0] as CLLocation
        
        //function will be called every time when user location changes.
        locationManager.stopUpdatingLocation()
        
        let center = CLLocationCoordinate2D(latitude: userLocation.coordinate.latitude, longitude: userLocation.coordinate.longitude)
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.03, longitudeDelta: 0.03))
        
        mapView.setRegion(region, animated: true)
      
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initializeLocation()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
