//
//  ViewController.swift
//  JokeSettings
//
//  Created by Kily N on 2/19/17.
//  Copyright © 2017 Kily N. All rights reserved.
//

import UIKit







class ViewController: UIViewController {

    
    @IBOutlet weak var sortByLabel: UILabel!
    
    
    @IBOutlet weak var shuffleLabel: UILabel!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    
    @IBOutlet weak var yesNoLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    
        
        
    }
    func updateText()
    {
        if (nameLabel != nil){
            if let nameStr = UserDefaults.standard.string(forKey: "name"){
                nameLabel.text = nameStr
                
            }
            else{nameLabel.text = "empty"}
            
    if (yesNoLabel != nil)
    {
        
        if (UserDefaults.standard.bool(forKey: "restrict_content"))
        {
            yesNoLabel.text = "Yes"
        
        }else { yesNoLabel.text = "No"  }
        
            }
        
        
        }
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        updateText()
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        let defaults = UserDefaults.standard
        
       // Shuffer    on/off
        if  (defaults.bool(forKey: "switchKeyName"))
        {
            
            self.shuffleLabel.text = "On"
            
        }
        else{
            
            self.shuffleLabel.text = "Off"
                   }
    // NAME LOCAL
    let a = defaults.integer(forKey: "RateViewsName")
    
    if (a == 0)
    {
       self.sortByLabel.text = "Rating"
       
    }
    else
    {
    
        self.sortByLabel.text = "Views"
  
    }
    ///////////GLOBAL////////////////
       
        // NAME GLOBAL
    if (defaults.object(forKey: "name") != nil)
        {
            self.nameLabel.text = defaults.string(forKey: "name")
        
        } else {self.nameLabel.text = ""}
        
    // for restrict content off/on
    if  (defaults.bool(forKey: "restrict_content"))
        {
            
            self.yesNoLabel.text = "Yes"
            
        }
        else{
            
            
            self.yesNoLabel.text = "No"
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

